"""Click through the real customer's photos after the bot has confirmed the list."""
import io
import json
from pathlib import Path
from unittest.mock import Mock

import openpyxl
from playwright.sync_api import expect
from audit.test_browser_round2 import server, site, browser, page, ART, ROOT
from catalog.csbot import CsBot
from scripts.verify_customer_photos import ReplayModel


def test_customer_real_photos_edit_and_download(page, site):
    dataset=json.loads((ROOT/'tests/fixtures/customer_photos.json').read_text())
    images={c['id']:(Path(dataset['source_dir'])/c['file']).read_bytes() for c in dataset['cases']}
    api=Mock();model=ReplayModel(dataset['cases'],images)
    bot=CsBot(site['conn'],api,llm=model,notifier=Mock(),img_dir=str(site['photo'].parent))
    for i,case in enumerate(dataset['cases'],700):
        api.download_photo.return_value=images[case['id']]
        bot.handle_update({'update_id':i,'message':{'chat':{'id':987},'from':{'id':987},'photo':[{'file_id':'f','width':1280}]}})
    cust=dict(site['conn'].execute("SELECT * FROM cs_customer WHERE tg_id='987'").fetchone())
    bot._confirm_drafts(cust);bot._make_link(cust)
    token=site['conn'].execute('SELECT token FROM cs_link WHERE customer_id=?',(cust['id'],)).fetchone()[0]
    page.set_viewport_size({'width':390,'height':844})
    page.goto(site['base']+'/cs/list.html?k='+token)
    expect(page.locator('table tr')).to_have_count(6)
    expect(page.locator('table')).to_contain_text('350mL')
    expect(page.locator('table')).to_contain_text('260g')
    expect(page.locator('table img')).to_have_count(5)
    page.wait_for_function("[...document.querySelectorAll('table img')].every(i=>i.complete && i.naturalWidth>0)")
    price=page.locator('[data-field="价格"]').first
    price.fill('2.5');page.locator('h1').click()
    expect(page.locator('#tip')).to_contain_text('已保存')
    page.reload();expect(page.locator('[data-field="价格"]').first).to_have_text('2.5')
    with page.expect_download() as download:
        page.get_by_role('button',name='⬇️ 导出 Excel').click()
    path=ART/'real-customer-click-export.xlsx';download.value.save_as(str(path))
    ws=openpyxl.load_workbook(path).active
    assert ws.max_row==6 and len(ws._images)==5
    assert any(cell.value=='2.5' for row in ws for cell in row)
