from playwright.sync_api import expect
from audit.test_browser_round2 import server, site, browser, page


def test_customer_showcase_mobile_browsing(page, site):
    from catalog.storage import LocalStorage
    storage = LocalStorage(str(site['folder'] / 'images'))
    photo = storage.save('razor','r1','main.jpg',site['photo'].read_bytes())
    site['conn'].execute("UPDATE product_razor SET cs_visible=1,image_main=? WHERE id='r1'",(photo,))
    site['conn'].commit()
    page.set_viewport_size({'width':390,'height':844})
    page.goto(site['base']+'/cs/products.html')
    expect(page.locator('.card')).to_have_count(2)
    page.get_by_role('button',name='卷发棒',exact=True).click()
    expect(page.locator('.card')).to_have_count(1)
    expect(page.locator('.card')).to_contain_text('CURLER-1')
    page.get_by_text('查看商品规格',exact=True).click()
    expect(page.locator('details')).to_have_attribute('open','')
    page.get_by_role('button',name='全部',exact=True).click()
    page.get_by_role('textbox',name='搜索商品').fill('RAZOR-1')
    expect(page.locator('.card')).to_have_count(1)
    page.get_by_role('button',name='放大 RAZOR-1 图片').click()
    expect(page.locator('#viewer')).to_be_visible()
    page.wait_for_function('document.querySelector("#viewer img").naturalWidth > 0')
    page.get_by_role('button',name='关闭大图').click()
    expect(page.locator('#viewer')).not_to_be_visible()
    page.get_by_role('textbox',name='搜索商品').fill('不存在型号')
    expect(page.locator('#products')).to_contain_text('没有匹配')
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
